import { Injectable } from "@angular/core";
import { of } from 'rxjs';

@Injectable()

export class RouterMock {

  initialNavigation() {}

  setUpLocationChangeListener() {}

  url() {}

  getCurrentNavigation() {}

  resetConfig() {}

  ngOnDestroy() {}

  dispose() {}

  navigate() {}

  serializeUrl() {}

  parseUrl() {}

  isActive() {}
}
